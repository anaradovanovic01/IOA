import math
import random
from copy import deepcopy
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def f(x, s):
    F1 = math.pow(2, 25)
    F2 = math.pow(2, 25)
    for i in range(64):
        if x[i] == 1:
            F1 -= s[i]
        if x[i] == 2:
            F2 -= s[i]
    if F1 < 0 or F2 < 0:
        fun = math.pow(2, 26)
    else:
        fun = F1 + F2
    return fun


def sim_kaljenje(x, s):
    t = 64 * 1024 * 1024
    a = 0.95
    hmin = 1
    hmax = 32
    itot = 100000
    values = []
    values.append(f(x, s))

    for i in range(itot):
        h = ((hmin-hmax)/(itot-1))*(i-1)+hmax
        x2 = deepcopy(x)
        for j in range(int(h)):
            elem = random.randint(0, 63)
            old = x2[elem]
            while old == x2[elem]:
                x2[elem] = random.randint(0, 2)

        f1 = f(x, s)
        f2 = f(x2, s)
        values.append(f2)
        E = f2 - f1
        if E < 0:
            x = deepcopy(x2)
        else:
            p = math.exp(-E/t)
            ran = random.random()
            if ran < p:
                x = deepcopy(x2)
        t = a * t

    series = pd.Series(values)
    mat.append(series.cummin())
    return x


s =(173669, 275487, 1197613, 1549805, 502334, 217684, 1796841, 274708, 631252, 148665, 150254, 4784408, 344759, 440109, 4198037, 329673, 28602, 144173, 1461469, 187895, 369313, 959307, 1482335, 2772513, 1313997, 254845, 486167, 2667146, 264004, 297223, 94694, 1757457, 576203, 8577828, 498382, 8478177, 123575, 4062389, 3001419, 196884, 617991, 421056, 3017627, 131936, 1152730, 2676649, 656678, 4519834, 201919, 56080, 2142553, 326263, 8172117, 2304253, 4761871, 205387, 6148422, 414559, 2893305, 2158562, 465972, 304078, 1841018, 1915571);
x = []
random.seed()
for i in range(64):
    x.append(random.randint(0, 2))

res = []
mat = []
xs = []
for i in range(20):
    for j in range(10):
        x = sim_kaljenje(x, s)
    res.append(f(x, s))
    xs.append(x)
    print(i, x)
    print(i, f(x, s))
    for j in range(64):
        x[j] = random.randint(0, 2)

minimum = min(res)
print("min", xs[res.index(minimum)])
print("min", minimum)

fig = plt.figure()
x = np.arange(0, 100001)

for i in range(20):
    plt.loglog(x, mat[i])
plt.savefig("grafik1.png")
plt.show()

fig = plt.figure()
c =[]
for i in range(100001):
    sum = 0
    for j in range(20):
        sum += mat[j][i]
    c.append(1/100000 * sum)
plt.loglog(x, c)
plt.savefig("grafik2.png")
plt.show()
